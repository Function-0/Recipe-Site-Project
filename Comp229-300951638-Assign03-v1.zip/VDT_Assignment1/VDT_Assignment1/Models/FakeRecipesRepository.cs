﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace VDT_Assignment1.Models
{
    public class FakeRecipesRepository 
    {      

        private static List<Recipe> recipes = new List<Recipe>
        {
            new Recipe {
                RecipeID = 1,
                PictureUrl ="https://s1.1zoom.me/b5356/608/Pasta_Plate_Bolognese_568188_1920x1080.jpg",
                RecipeName = "Family Tradition Bolognese Pasta",
                Description = "Delicious Spaghetti al dente with Homemade Bolognese Pasta!",
                Ingredients = "1 tbsp olive oil,\r 4 rashers smoked streaky bacon, 2 medium onions, 2 carrots, 2 celery sticks, 2 garlic cloves, 2-3 sprigs rosemary leaves picked and chopped, 500g beef mince, 2 x 400g tins plum tomatoes, small pack basil , leaves picked, ¾ finely chopped and the rest left whole for garnish, 1 tsp dried oregano, 2 fresh bay leaves, 2 tbsp tomato purée, 1 beef stock cube, 125ml red wine, 6 cherry tomatoes, sliced in half, 75g parmesan, grated, plus extra to serve, 400g spaghetti",
                PrepareMode = "1. Put a large saucepan on a medium heat and add 1 tbsp olive oil. "  +
                "2. Add 4 finely chopped bacon rashers and fry for 10 mins until golden and crisp. " +
                "3. Reduce the heat and add the 2 onions, 2 carrots, 2 celery sticks, 2 garlic cloves and the leaves from 2-3 sprigs rosemary, all finely chopped, then fry for 10 mins. Stir the veg often until it softens. " +
                "4. Increase the heat to medium-high, add 500g beef mince and cook stirring for 3-4 mins until the meat is browned all over." +
                "5. Add 2 tins plum tomatoes, the finely chopped leaves from ¾ small pack basil, 1 tsp dried oregano, 2 bay leaves, 2 tbsp tomato purée, 1 beef stock cube, 1 deseeded and finely chopped red chilli (if using), 125ml red wine and 6 halved cherry tomatoes. Stir with a wooden spoon, breaking up the plum tomatoes. " +
                "6. Bring to the boil, reduce to a gentle simmer and cover with a lid. Cook for 1 hr 15 mins stirring occasionally, until you have a rich, thick sauce. " +
                "7. Add the 75g grated parmesan, check the seasoning and stir. " +
                "8. When the bolognese is nearly finished, cook 400g spaghetti following the pack instructions. " +
                "9. Drain the spaghetti and stir into the bolognese sauce. Serve with more grated parmesan, the remaining basil leaves and crusty bread, if you like. ",
                TimeToPrepare = 30
            },
            new Recipe {
                RecipeID = 2,
                PictureUrl ="https://s1.1zoom.me/b5348/64/Tomatoes_Garlic_Spices_Pasta_Plate_Fork_519009_1920x1080.jpg",
                RecipeName = "Grandma Tereza Agli Oli Tomato Pasta",
                Description = "Agli Ogli Spaghetti with Tomatoes ",
                Ingredients = "500g pack wholewheat spaghetti, 300g tomatoes,3 tbsp olive oil, plus extra to serve, 4 garlic cloves, finely sliced, 2 tbsp red wine vinegar, 50g parmesan, half grated, half shaved, chilli flakes, to serve ",
                PrepareMode = "1. Cook the spaghetti according to pack instructions. Meanwhile, boil the kettle and tip the tomatoes into a large colander. Pour on boiling water until it’s completely wilted (you may need 2 kettles of water), then cool under cold water and cut the tomatoes in half. " +
                "2. Very gently heat the oil and garlic in a small pan for a few mins until it just starts to brown, then add the vinegar. Bubble for 1 min, then turn off the heat. When the spaghetti is cooked, reserve some of the water, then drain. In a large bowl, toss the spaghetti with the garlicky oil, tomatoes, pine nuts and the grated Parmesan. Add enough water to loosen everything. Serve in bowls along with the Parmesan shavings and chilli flakes, plus more olive oil for drizzling.",
                TimeToPrepare = 25
            },
            new Recipe {
                RecipeID = 3,
                PictureUrl ="https://w.wallhaven.cc/full/2e/wallhaven-2e31zg.jpg",
                RecipeName = "Aunt Cristina Special Capeletti",
                Description = "Traditional Italian Capeletti with Wild Mushroom Sauce",
                Ingredients = "1/2 lb. ricotta, 1/2 lb. squaquerone cheese (or substitute stracchino, teleme, or basket cheese), 1 cup grated Parmigiano Reggiano, 1/2 cup grated pecorino cheese, 1 egg, Freshly grated nutmeg, Kosher salt, Freshly ground pepper, 1 recipe basic pasta dough, 1 shallot, cut into fine dice, 2 Tbs. extra virgin olive oil, 1 lb. sliced mixed wild mushrooms (oyster, cremini, shiitake), 1/2 cup white wine, 1/2 cup chopped flat-leaf parsley.",
                PrepareMode = "In a large bowl, mix together the ricotta, squaquerone, Parmigiano Reggiano, pecorino, egg, nutmeg, and salt and pepper to taste.Divide the pasta dough into 6 pieces. Using a pasta machine, roll each piece out, starting with the widest setting and ending with the thinnest. Cut the pasta sheets into 2-inch squares. Place 1 tsp. of filling in the center of each square. Fold the square into triangles and press firmly to secure the filling. Bring the two bottom points of each triangle together to form the “little hats.” Place the cappelletti on a lightly floured sheet pan and continue filling the rest of the pasta. Make the sauce: sauté the shallot in 2 Tbs. of olive oil over medium heat until tender, about 5 minutes. Add the mushrooms and cook until the mushrooms release their liquid, 5 to 7 minutes. Season with salt and pepper to taste, then add the white wine and let reduce by half." +
                "Bring 6 quarts of salted water to a boil. Drop the cappelletti into the water and cook until they start to float to the top, 2 to 3 minutes. Drain the pasta and toss in the sauté pan with the mushrooms. Sprinkle with chopped parsley. Serve in individual shallow bowls.", 
                TimeToPrepare = 35
            }
        };
        public IQueryable<Recipe> Recipes => recipes.AsQueryable<Recipe>();
        public static void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
        }
    }
}


﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

using VDT_Assignment1.Models;

namespace VDT_Assignment1
{
    public class Startup
    {
        // This method gets called by the runtime. Use this method to add services to the container.
        // For more information on how to configure your application, visit https://go.microsoft.com/fwlink/?LinkID=398940
        public Startup(IConfiguration configuration) =>
            Configuration = configuration;

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddDbContext<ApplicationDbContext>(options =>
                options.UseSqlServer(
                    Configuration["Data:DallarosaRecipes:ConnectionString"]));
            services.AddTransient<IRecipesRepository, EFRecipeRepository>();            
            services.AddSingleton<IHttpContextAccessor, HttpContextAccessor>();
            services.AddMvc();
            services.AddMemoryCache();
            //services.AddSession();
        }

        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            app.UseDeveloperExceptionPage();
            app.UseStatusCodePages();
            app.UseStaticFiles();
            //app.UseSession();
            app.UseMvc(routes => {
                routes.MapRoute(
                    name: null,
                    template: "",
                    defaults: new { controller = "Home", action = "Index" }
                    );

                routes.MapRoute(
                    name: null,
                    template: "Recipes",
                    defaults: new { controller = "Recipe", action = "DataPage" }
                    );

                routes.MapRoute(
                    name: null,
                    template: "Recipes/{RecipeID:int?}",
                    defaults: new { controller = "Recipe", action = "DisplayPage" }
                    );


                routes.MapRoute(
                    name: null,
                    template: "Recipes/New",
                    defaults: new { controller = "Recipe", action = "New" }
                    );

                routes.MapRoute(
                    name: null,
                    template: "Recipes/Edit/{RecipeId:int?}",
                    defaults: new { controller = "Recipe", action = "Edit" }
                    );

                routes.MapRoute(
                    name: null,
                    template: "Login",
                    defaults: new { controller = "Recipe", action = "Admin" }
                    );

            });
            SeedData.EnsurePopulated(app);
        }
    }
}

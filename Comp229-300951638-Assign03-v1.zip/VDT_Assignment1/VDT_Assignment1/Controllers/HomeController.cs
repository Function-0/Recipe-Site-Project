﻿using Microsoft.AspNetCore.Mvc;
using VDT_Assignment1.Models;
using System.Linq;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace VDT_Assignment1.Controllers
{
    public class HomeController : Controller
    {
        private IRecipesRepository repository;
        public HomeController(IRecipesRepository repo)
        {
            repository = repo;
        }

        public IActionResult Index()
        {
            return View();
        }

    }
}

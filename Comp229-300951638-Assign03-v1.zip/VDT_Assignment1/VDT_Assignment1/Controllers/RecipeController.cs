﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using VDT_Assignment1.Models;

namespace VDT_Assignment1.Controllers
{
    public class RecipeController : Controller
    {
        private IRecipesRepository repository;

        public RecipeController(IRecipesRepository repo)
        {
            repository = repo;
        }

        public ViewResult DataPage() => View(repository.Recipes);

        public ViewResult DisplayPage(int recipeID) =>
            View(repository.Recipes
                .FirstOrDefault(r => r.RecipeID == recipeID));

        [HttpGet]
        public ViewResult Edit(int recipeId) =>
           View("InsertPage", repository.Recipes
           .FirstOrDefault(r => r.RecipeID == recipeId));

        [HttpPost]
        public IActionResult Edit(Recipe recipe)
        {
            if (ModelState.IsValid)
            {
                repository.SaveRecipe(recipe);
                TempData["message"] = $"{recipe.RecipeName} has been saved";
                return View("DataPage", repository.Recipes);
            }
            else
            {
                // there is something wrong with the data values
                return View("InsertPage", recipe);
            }
        }
        public ViewResult New() => View("InsertPage", new Recipe());

        public IActionResult Admin()
        {
            return View("UserPage");
        }


    }
}


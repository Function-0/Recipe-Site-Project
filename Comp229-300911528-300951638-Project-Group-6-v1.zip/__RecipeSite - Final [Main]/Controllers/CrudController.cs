﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using RecipeSite.Models;
using RecipeSite.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;

namespace RecipeSite.Controllers
{
    [Authorize]
    public class CrudController : Controller
    {
        private IRecipeRepository repository;
        private IHostingEnvironment _env;

        public CrudController(IRecipeRepository repo, IHostingEnvironment env)
        {
            repository = repo;
            _env = env;
        }

        public IActionResult DeleteData(RecipeFormViewModelData recipe) 
        {
            String user = User.Identity.Name;
            RecipeItem userRecipe = repository.Recipes.Where(
                r => (r.RecipeId == recipe.RecipeId)).FirstOrDefault<RecipeItem>();

            if (userRecipe.UserName != user)
            {
                TempData["message"] = $"Action Denied: {user} is not original writer of recipe.";
                TempData["type"] = "Denied";
            }
            else
            {
                TempData["message"] = "Recipe Successfully Deleted.";
                TempData["type"] = "Success";

                RecipeItem newRecipe = new RecipeItem();
                newRecipe.RecipeName = recipe.RecipeName;
                newRecipe.PictureUrl = recipe.PictureUrl;
                newRecipe.ServingSize = recipe.ServingSize;
                newRecipe.Description = recipe.Description;
                newRecipe.RecipeId = recipe.RecipeId;
                Ingredient newIngredient = new Ingredient();
                newIngredient.IngredientName = recipe.Ingredient;
                newIngredient.IngredientId = recipe.RecipeId;
                Equipment newEquipment = new Equipment();
                newEquipment.EquipmentName = recipe.Equipment;
                newEquipment.EquipmentId = recipe.RecipeId;
                newRecipe.Instructions = recipe.Instructions;
                Review newReview = new Review();
                newReview.ReviewText = recipe.Review;
                newReview.ReviewId = recipe.RecipeId;

                repository.DeleteRecipe(newRecipe);
                repository.DeleteReview(newReview);
                repository.DeleteIngredient(newIngredient);
                repository.DeleteEquipment(newEquipment);
            }
            
            return RedirectToAction("DataPage", "Home");
        }

        [HttpPost]
        public IActionResult Delete(RecipeItem recipe)
        {
            var test = recipe;
            RecipeFormViewModel recipeData = new RecipeFormViewModel();
            recipeData.Recipe = repository.Recipes.Where(r => r.RecipeId == recipe.RecipeId).FirstOrDefault<RecipeItem>();
            recipeData.Equipment = repository.Equipment.Where(r => r.EquipmentId == recipe.RecipeId).FirstOrDefault<Equipment>();
            recipeData.Ingredient = repository.Ingredients.Where(r => r.IngredientId == recipe.RecipeId).FirstOrDefault<Ingredient>();
            recipeData.Review = repository.Reviews.Where(r => r.ReviewId == recipe.RecipeId).FirstOrDefault<Review>();

            RecipeFormViewModelData recipeDataOutput = new RecipeFormViewModelData();
            recipeDataOutput.RecipeId = recipeData.Recipe.RecipeId;
            recipeDataOutput.ImageFile = recipeData.Recipe.ImageFile;
            recipeDataOutput.PictureUrl = recipeData.Recipe.PictureUrl;
            recipeDataOutput.RecipeName = recipeData?.Recipe?.RecipeName;
            recipeDataOutput.ServingSize = recipeData.Recipe.ServingSize;
            recipeDataOutput.Description = recipeData?.Recipe?.Description;
            recipeDataOutput.Ingredient = recipeData?.Ingredient?.IngredientName;
            recipeDataOutput.Equipment = recipeData?.Equipment?.EquipmentName;
            recipeDataOutput.Review = recipeData?.Review?.ReviewText;
            recipeDataOutput.Instructions = recipeData?.Recipe?.Instructions;

            return RedirectToAction("DeleteData", "Crud", recipeDataOutput);
        }

        [HttpPost]
        public IActionResult Edit(RecipeItem recipe)
        {
            String user = User.Identity.Name;
            RecipeItem userRecipe = repository.Recipes.Where(
                r => (r.RecipeId == recipe.RecipeId)).FirstOrDefault<RecipeItem>();


            if (userRecipe.UserName != user)
            {
                TempData["message"] = $"Action Denied: {user} is not original writer of recipe.";
                TempData["type"] = "Denied";

                return RedirectToAction("DataPage", "Home");
            }
            else
            {
                RecipeFormViewModel recipeData = new RecipeFormViewModel();
                recipeData.Recipe = repository.Recipes.Where(r => r.RecipeId == recipe.RecipeId).FirstOrDefault<RecipeItem>();
                recipeData.Equipment = repository.Equipment.Where(r => r.EquipmentId == recipe.RecipeId).FirstOrDefault<Equipment>();
                recipeData.Ingredient = repository.Ingredients.Where(r => r.IngredientId == recipe.RecipeId).FirstOrDefault<Ingredient>();
                recipeData.Review = repository.Reviews.Where(r => r.ReviewId == recipe.RecipeId).FirstOrDefault<Review>();

                RecipeFormViewModelData recipeDataOutput = new RecipeFormViewModelData();
                recipeDataOutput.RecipeId = recipeData.Recipe.RecipeId;
                recipeDataOutput.ImageFile = recipeData.Recipe.ImageFile;
                recipeDataOutput.PictureUrl = recipeData.Recipe.PictureUrl;
                recipeDataOutput.RecipeName = recipeData?.Recipe?.RecipeName;
                recipeDataOutput.ServingSize = recipeData.Recipe.ServingSize;
                recipeDataOutput.Description = recipeData?.Recipe?.Description;
                recipeDataOutput.Ingredient = recipeData?.Ingredient?.IngredientName;
                recipeDataOutput.Equipment = recipeData?.Equipment?.EquipmentName;
                recipeDataOutput.Review = recipeData?.Review?.ReviewText;
                recipeDataOutput.Instructions = recipeData?.Recipe?.Instructions;
                recipeDataOutput.LastEditTime = recipeData.Recipe.LastEditTime;

                return View(recipeDataOutput);
            }
        }

        [HttpPost]
        public IActionResult InsertPage(RecipeFormViewModelData recipe)
        {
            // If recipe image has been changed
            if (recipe.ImageFile != null)
            {
                string fileName = Path.GetFileNameWithoutExtension(recipe.ImageFile.FileName);
                string extension = Path.GetExtension(recipe.ImageFile.FileName);
                fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                recipe.PictureUrl = Path.Combine(_env.WebRootPath, "/images/" + fileName);
                fileName = Path.Combine(_env.WebRootPath, "images/" + fileName);
                recipe.ImageFile.CopyTo(new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite));
            }
            

            RecipeItem newRecipe = new RecipeItem();
            newRecipe.RecipeName = recipe.RecipeName;
            newRecipe.PictureUrl = recipe.PictureUrl;
            newRecipe.ServingSize = recipe.ServingSize;
            newRecipe.Description = recipe.Description;
            newRecipe.RecipeId = recipe.RecipeId;
            newRecipe.ImageFile = recipe.ImageFile;
            Ingredient newIngredient = new Ingredient();
            newIngredient.IngredientName = recipe.Ingredient;
            newIngredient.IngredientId = recipe.RecipeId;
            Equipment newEquipment = new Equipment();
            newEquipment.EquipmentName = recipe.Equipment;
            newEquipment.EquipmentId = recipe.RecipeId;
            newRecipe.Instructions = recipe.Instructions;
            newRecipe.LastEditTime = recipe.LastEditTime;

            repository.SaveRecipe(newRecipe);
            repository.SaveIngredient(newIngredient);
            repository.SaveEquipment(newEquipment);

            return RedirectToAction("DataPage", "Home");
        }

        public IActionResult Index()
        {
            return View();
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using RecipeSite.Models;
using RecipeSite.Models.ViewModels;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Authorization;

namespace RecipeSite.Controllers
{
    public class HomeController : Controller
    {
        private IHostingEnvironment _env;
        

        private IRecipeRepository repository;

        public HomeController(IRecipeRepository repo, IHostingEnvironment env)
        {
            repository = repo;
            _env = env;
        }

        
        public ViewResult Index()
        {
            return View();
        }

        [HttpPost]
        public ViewResult DisplayPage(RecipeItem recipe)
        {
            int test = recipe.RecipeId;

            RecipeFormViewModel recipeData = new RecipeFormViewModel();
            recipeData.Recipe = repository.Recipes.Where(r => r.RecipeId == recipe.RecipeId).FirstOrDefault<RecipeItem>();
            recipeData.Equipment = repository.Equipment.Where(r => r.EquipmentId == recipe.RecipeId).FirstOrDefault<Equipment>();
            recipeData.Ingredient = repository.Ingredients.Where(r => r.IngredientId == recipe.RecipeId).FirstOrDefault<Ingredient>();
            recipeData.Review = repository.Reviews.Where(r => r.ReviewId == recipe.RecipeId).FirstOrDefault<Review>();
            

            RecipeFormViewModelData recipeDataOutput = new RecipeFormViewModelData();
            recipeDataOutput.RecipeId = recipeData.Recipe.RecipeId;
            recipeDataOutput.PictureUrl = recipeData.Recipe.PictureUrl;
            recipeDataOutput.RecipeName = recipeData?.Recipe?.RecipeName;
            recipeDataOutput.ServingSize = recipeData.Recipe.ServingSize;
            recipeDataOutput.Description = recipeData?.Recipe?.Description;
            recipeDataOutput.Ingredient = recipeData?.Ingredient?.IngredientName;
            recipeDataOutput.Equipment = recipeData?.Equipment?.EquipmentName;
            recipeDataOutput.Review = recipeData?.Review?.ReviewText;
            recipeDataOutput.Instructions = recipeData?.Recipe?.Instructions;
            recipeDataOutput.UserName = recipeData?.Recipe?.UserName;
            recipeDataOutput.LastEditTime = recipeData.Recipe.LastEditTime;
            

            return View(recipeDataOutput);
        }

        [HttpGet]
        [Authorize]
        public ViewResult InsertPage()
        {
            return View(new RecipeFormViewModelData());
        }

        [HttpPost]
        [Authorize]
        public ViewResult InsertPage(RecipeFormViewModelData recipe)
        {
            if (ModelState.IsValid)
            {
                string fileName = Path.GetFileNameWithoutExtension(recipe.ImageFile.FileName);
                string extension = Path.GetExtension(recipe.ImageFile.FileName);
                fileName = fileName + DateTime.Now.ToString("yymmssfff") + extension;
                recipe.PictureUrl = Path.Combine(_env.WebRootPath, "/images/" + fileName);
                fileName = Path.Combine(_env.WebRootPath, "images/" + fileName);
                recipe.ImageFile.CopyTo(new FileStream(fileName, FileMode.Create, FileAccess.ReadWrite));
                



                RecipeItem newRecipe = new RecipeItem();
                newRecipe.ImageFile = recipe.ImageFile;
                newRecipe.RecipeName = recipe.RecipeName;
                newRecipe.PictureUrl = recipe.PictureUrl;
                newRecipe.ServingSize = recipe.ServingSize;
                newRecipe.Description = recipe.Description;
                Ingredient newIngredient = new Ingredient();
                newIngredient.IngredientName = recipe.Ingredient;
                Equipment newEquipment = new Equipment();
                newEquipment.EquipmentName = recipe.Equipment;
                newRecipe.Instructions = recipe.Instructions;
                newRecipe.UserName = User.Identity.Name;
                newRecipe.LastEditTime = recipe.LastEditTime;

                repository.AddRecipe(newRecipe);
                repository.AddIngredient(newIngredient);
                repository.AddEquipment(newEquipment);
                
                return View("DataPage", repository.Recipes);
            }
            else
            {
                return View();
            }
            
        }

        public ActionResult DataPage(string searchBy, string logic, string search, string search2, string search3)
        {
            // search
            bool case1 = !String.IsNullOrEmpty(search) && (String.IsNullOrEmpty(search2) && String.IsNullOrEmpty(search3));

            // search2
            bool case2 = !String.IsNullOrEmpty(search2) && (String.IsNullOrEmpty(search) && String.IsNullOrEmpty(search3));

            // search3
            bool case3 = !String.IsNullOrEmpty(search3) && (String.IsNullOrEmpty(search) && String.IsNullOrEmpty(search2));

            // search + search2
            bool case4 = (!String.IsNullOrEmpty(search) && !String.IsNullOrEmpty(search2)) && String.IsNullOrEmpty(search3);

            // search + search3
            bool case5 = (!String.IsNullOrEmpty(search) && !String.IsNullOrEmpty(search3)) && String.IsNullOrEmpty(search2);

            // search2 + search3
            bool case6 = (!String.IsNullOrEmpty(search2) && !String.IsNullOrEmpty(search3)) && String.IsNullOrEmpty(search);

            // search + search2 + search3
            bool case7 = !String.IsNullOrEmpty(search) && !String.IsNullOrEmpty(search2) && !String.IsNullOrEmpty(search3);

            // All empty
            bool case8 = String.IsNullOrEmpty(search) && String.IsNullOrEmpty(search2) && String.IsNullOrEmpty(search3);



            if ((searchBy == "Name") && !case8)
            {
                if (logic == "AND")
                {
                    if (case1)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search)));
                    }
                    else if (case2)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search2)));
                    }
                    else if (case3)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search3)));
                    }
                    else if (case4)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search) && x.RecipeName.Contains(search2)));
                    }
                    else if (case5)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search) && x.RecipeName.Contains(search3)));
                    }
                    else if (case6)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search2) && x.RecipeName.Contains(search3)));
                    }
                    else if (case7)
                    {
                        return View(repository.Recipes.Where(x => x.RecipeName.Contains(search) && x.RecipeName.Contains(search2) && x.RecipeName.Contains(search3)));
                    }
                    return View(repository.Recipes.Where(x => x.RecipeName.Contains(search) && x.RecipeName.Contains(search2) && x.RecipeName.Contains(search3) || search == null).ToList());
                }
                else
                {
                    return View(repository.Recipes.Where(x => x.RecipeName.Contains(search) || x.RecipeName.Contains(search2) || x.RecipeName.Contains(search3)).ToList());
                }
            }
            else if ((searchBy == "Description") && !case8)
            {
                if (logic == "AND")
                {
                    if (case1)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search)));
                    }
                    else if (case2)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search2)));
                    }
                    else if (case3)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search3)));
                    }
                    else if (case4)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search) && x.Description.Contains(search2)));
                    }
                    else if (case5)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search) && x.Description.Contains(search3)));
                    }
                    else if (case6)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search2) && x.Description.Contains(search3)));
                    }
                    else if (case7)
                    {
                        return View(repository.Recipes.Where(x => x.Description.Contains(search) && x.Description.Contains(search2) && x.Description.Contains(search3)));
                    }
                    return View(repository.Recipes.Where(x => x.Description.Contains(search) && x.Description.Contains(search2) && x.Description.Contains(search3) || search == null).ToList());
                }
                else
                {
                    return View(repository.Recipes.Where(x => x.Description.Contains(search) || x.Description.Contains(search2) || x.Description.Contains(search3)).ToList());
                }
            }
            else
            {
                return View(repository.Recipes);
            }
        }

        public ViewResult UserPage()
        {
            return View(repository.Recipes);
        }

        [Authorize]
        public IActionResult ReviewInitial(RecipeItem recipe)
        {
            String user = User.Identity.Name;
            RecipeItem userRecipe = repository.Recipes.Where(
                r => (r.RecipeId == recipe.RecipeId)).FirstOrDefault<RecipeItem>();

            if (userRecipe.UserName == user)
            {
                TempData["message"] = $"Action Denied: {user} is not allowed to review their own recipe.";
                TempData["type"] = "Denied";

                return RedirectToAction("UserPage");
            }

            else
            {
                RecipeFormViewModelData recipeData = new RecipeFormViewModelData();
                recipeData.RecipeId = recipe.RecipeId;

                return View("Review", recipeData);
            }
            
        }


        [HttpPost]
        [Authorize]
        public IActionResult Review(RecipeFormViewModelData recipeData)
        {
            // Check if user created a review before
            String user = User.Identity.Name;
            Review existingReview = repository.Reviews.Where(
                r => (r.RecipeId == recipeData.RecipeId) && (r.UserName == user)).FirstOrDefault<Review>();

            if (existingReview != null)
            {
                existingReview.ReviewText = recipeData.Review;
                repository.SaveReview(existingReview);
            }
            // Create a new review database entry otherwise
            else
            {
                Review newReview = new Review();
                newReview.ReviewText = recipeData.Review;
                newReview.RecipeId = recipeData.RecipeId;
                newReview.UserName = User.Identity.Name;
                repository.AddReview(newReview);
            }

            return RedirectToAction("UserPage");
        }

        [HttpPost]
        public IActionResult ReviewInitialAll(RecipeItem recipe)
        {
            var test = repository.Reviews.Where(r => r.RecipeId == recipe.RecipeId);
            return View("ReviewAll", repository.Reviews.Where(r => r.RecipeId == recipe.RecipeId));
        }

    }
}
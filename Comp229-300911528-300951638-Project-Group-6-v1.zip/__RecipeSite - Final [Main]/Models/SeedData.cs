﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.EntityFrameworkCore;

namespace RecipeSite.Models
{
    public static class SeedData
    {
        public static void EnsurePopulated(IApplicationBuilder app)
        {
            const string testUser1 = "TestAccount1";
            const string testUser2 = "TestAccount2";

            ApplicationDbContext context = app.ApplicationServices
                .GetRequiredService<ApplicationDbContext>();
            context.Database.Migrate();
            if (!context.Recipes.Any())
            {
                context.Recipes.AddRange(
                    new RecipeItem
                    {
                        PictureUrl = "https://cdn.sallysbakingaddiction.com/wp-content/uploads/2013/04/triple-chocolate-cake-4.jpg",
                        RecipeName = "Chocolate Cake",
                        ServingSize = 10,
                        Description = "This is a Mexican chocolate cake.",
                        Instructions = "1. Add Flour.\n2. Mix with cake batter.\n3. Put in oven.\n4. Eat.",
                        UserName = testUser1,
                        LastEditTime = System.DateTime.Now
                    },
                    new RecipeItem
                    {
                        PictureUrl = "https://upload.wikimedia.org/wikipedia/commons/thumb/7/77/Puffed_Rice_Cakes.jpg/1200px-Puffed_Rice_Cakes.jpg",
                        RecipeName = "Cake of Rice",
                        ServingSize = 5,
                        Description = "This is a Asian-style cake.",
                        Instructions = "1. Boil rice.\n2. Pour soy sauce with cake mixture.\n3. Deep fry.\n4. Eat.",
                        UserName = testUser2,
                        LastEditTime = System.DateTime.Now
                    },
                    new RecipeItem
                    {
                        PictureUrl = "http://www.cookwithamber.com/wp-content/uploads/2013/03/Riceabll_logo.jpg",
                        RecipeName = "Rice of Balls",
                        ServingSize = 1,
                        Description = "These are rice balls.",
                        Instructions = "1. Boil rice.\n2. Roll rice into small balls.\n3. Eat.",
                        UserName = testUser1,
                        LastEditTime = System.DateTime.Now
                    },
                    new RecipeItem
                    {
                        PictureUrl = "https://files2.hungryforever.com/wp-content/uploads/2015/10/10142949/dsen1.jpg",
                        RecipeName = "Deep South Eggnog Cake",
                        ServingSize = 3,
                        Description = "Delicious Eggnog Cake for Christmas Time.",
                        Instructions = "1. Preheat oven to 350 degrees F (175 degrees C). Grease and flour two 9-inch round baking pans.\n2. Beat 1/2 cup butter and 1 1/4 cups sugar with an electric mixer in a large bowl until light and fluffy. Mixture should be noticeably lighter in color. Add eggs, one at a time, allowing each egg to blend into butter mixture before adding the next. Stir in 1 teaspoon vanilla extract and 1/4 teaspoon lemon peel, mixing well.\n3. Spread cake with plain frosting between cake layers, over the top and on the sides. Coat the sides with toasted pecans, pressing the nuts onto sides in small handfuls. Refrigerate until serving time.",
                        UserName = testUser2,
                        LastEditTime = System.DateTime.Now
                    },
                    new RecipeItem
                    {
                        PictureUrl = "https://images.media-allrecipes.com/userphotos/720x405/7365514.jpg",
                        RecipeName = "Cranberry Orange Cake",
                        ServingSize = 2,
                        Description = "A yummy fall cranberry cake with a hint of orange! Dust with powdered sugar, if desired.",
                        Instructions = "1. Preheat the oven to 350 degrees F (175 degrees C). Grease a 10-inch fluted tube pan (such as Bundt(R)) with baking spray.\n2. Combine flour, sugar, oil, eggs, orange juice, baking powder, vanilla extract, and salt in a bowl using an electric mixer until thoroughly incorporated. Stir in cranberries and orange zest. Pour into the prepared pan.\n3. Bake in the preheated oven until a toothpick inserted into the center comes out clean, about 1 hour.\n4. Remove from the oven and turn cake out onto a cooling rack; let cool for 1 hour.",
                        UserName = testUser1,
                        LastEditTime = System.DateTime.Now
                    }
                );
            }
            if (!context.Ingredients.Any())
            {
                context.Ingredients.AddRange(
                    new Ingredient
                    {
                        IngredientName = "Chocolate"
                    },
                    new Ingredient
                    {
                        IngredientName = "Rice"
                    },
                    new Ingredient
                    {
                        IngredientName = "Fried Rice"
                    },
                    new Ingredient
                    {
                        IngredientName = "Eggnog"
                    },
                    new Ingredient
                    {
                        IngredientName = "Cranberry"
                    }
                );
            }
            if (!context.Equipment.Any())
            {
                context.Equipment.AddRange(
                    new Equipment
                    {
                        EquipmentName = "Large Pan"
                    },
                    new Equipment
                    {
                        EquipmentName = "Pot"
                    },
                    new Equipment
                    {
                        EquipmentName = "Plate"
                    },
                    new Equipment
                    {
                        EquipmentName = "Round Baking Pan"
                    },
                    new Equipment
                    {
                        EquipmentName = "Fluted Tube Pan"
                    }
                );
            }
            if (!context.Reviews.Any())
            {
                context.Reviews.AddRange(
                    new Review
                    {
                        ReviewText = "10/10 Loved it.",
                        RecipeId = 1,
                        UserName = "SuperMan64"
                        
                    },
                    new Review
                    {
                        ReviewText = "This sucks.",
                        RecipeId = 2,
                        UserName = "PatrickGignac"
                    },
                    new Review
                    {
                        ReviewText = "I rather eat rice.",
                        RecipeId = 3,
                        UserName = "IbrahimJomaa"
                    },
                    new Review
                    {
                        ReviewText = "Amazing for christmas!",
                        RecipeId = 4,
                        UserName = "VictorTeixeira"
                    },
                    new Review
                    {
                        ReviewText = "Loved it.",
                        RecipeId = 5,
                        UserName = "ElonMusk"
                    }
                );
            }
            context.SaveChanges();
        }
    }
}

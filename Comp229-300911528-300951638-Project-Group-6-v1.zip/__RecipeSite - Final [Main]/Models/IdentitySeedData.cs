﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.DependencyInjection;

namespace RecipeSite.Models
{
    public class IdentitySeedData
    {
        private const string testUser1 = "TestAccount1";
        private const string testUser2 = "TestAccount2";
        private const string testPassword = "Secret123$";

        public static async void EnsurePopulated(IApplicationBuilder app)
        {
            UserManager<IdentityUser> userManager = app.ApplicationServices
                .GetRequiredService<UserManager<IdentityUser>>();

            
            IdentityUser user = await userManager.FindByIdAsync(testUser1);
            if (user == null)
            {
                user = new IdentityUser(testUser1);
                await userManager.CreateAsync(user, testPassword);
            }

            user = await userManager.FindByIdAsync(testUser2);
            if (user == null)
            {
                user = new IdentityUser(testUser2);
                await userManager.CreateAsync(user, testPassword);
            }

        }
    }
}

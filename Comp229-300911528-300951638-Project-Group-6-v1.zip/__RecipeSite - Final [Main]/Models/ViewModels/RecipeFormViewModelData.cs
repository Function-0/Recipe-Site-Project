﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace RecipeSite.Models.ViewModels
{
    public class RecipeFormViewModelData
    {
        public int RecipeId { get; set; }
        public string PictureUrl { get; set; }
        public IFormFile ImageFile { get; set; }
        [Required(ErrorMessage = "Please type a recipe name")]
        public string RecipeName { get; set; }
        public int ServingSize { get; set; }
        public string Description { get; set; }
        [Required(ErrorMessage = "A ingredient is required")]
        public string Ingredient { get; set; }
        [Required(ErrorMessage = "A equipment is required")]
        public string Equipment { get; set; }
        public string Review { get; set; }
        public string Instructions { get; set; }
        public string UserName { get; set; }
        public DateTime LastEditTime { get; set; }
    }
}
